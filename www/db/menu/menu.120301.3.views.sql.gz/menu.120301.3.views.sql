-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2012 at 11:11 PM
-- Server version: 5.1.56
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hleong25_menudb1`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `vMenuStatus`
--
DROP VIEW IF EXISTS `vMenuStatus`;
CREATE TABLE IF NOT EXISTS `vMenuStatus` (
`id` int(11)
,`menu_status` varchar(20)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vPermissions`
--
DROP VIEW IF EXISTS `vPermissions`;
CREATE TABLE IF NOT EXISTS `vPermissions` (
`id` int(11)
,`permission` varchar(20)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vUserStatus`
--
DROP VIEW IF EXISTS `vUserStatus`;
CREATE TABLE IF NOT EXISTS `vUserStatus` (
`id` int(11)
,`user_status` varchar(20)
);
-- --------------------------------------------------------

--
-- Structure for view `vMenuStatus`
--
DROP TABLE IF EXISTS `vMenuStatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`hleong25`@`localhost` SQL SECURITY DEFINER VIEW `vMenuStatus` AS select `tblEnums`.`id` AS `id`,`tblEnums`.`eValue` AS `menu_status` from `tblEnums` where (`tblEnums`.`eType` = _utf8'menu_status');

-- --------------------------------------------------------

--
-- Structure for view `vPermissions`
--
DROP TABLE IF EXISTS `vPermissions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`hleong25`@`localhost` SQL SECURITY DEFINER VIEW `vPermissions` AS select `tblEnums`.`id` AS `id`,`tblEnums`.`eValue` AS `permission` from `tblEnums` where (`tblEnums`.`eType` = _utf8'permissions');

-- --------------------------------------------------------

--
-- Structure for view `vUserStatus`
--
DROP TABLE IF EXISTS `vUserStatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`hleong25`@`localhost` SQL SECURITY DEFINER VIEW `vUserStatus` AS select `tblEnums`.`id` AS `id`,`tblEnums`.`eValue` AS `user_status` from `tblEnums` where (`tblEnums`.`eType` = _utf8'user_status');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
