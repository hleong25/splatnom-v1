-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2013 at 01:17 AM
-- Server version: 5.5.30-30.2
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hleong25_menudb1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblCacheGeocode`
--

CREATE TABLE IF NOT EXISTS `tblCacheGeocode` (
  `address_query` char(200) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`address_query`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblEmailQueue`
--

CREATE TABLE IF NOT EXISTS `tblEmailQueue` (
  `mail_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_id` int(11) NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `send_response` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `from_addy` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `to_addy` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`mail_id`),
  KEY `fk_tblEmailQueue_1_idx` (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblEvent`
--

CREATE TABLE IF NOT EXISTS `tblEvent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mod_ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mode_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tblEvent_1_idx` (`mode_id`),
  KEY `fk_tblEvent_2_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblEventDates`
--

CREATE TABLE IF NOT EXISTS `tblEventDates` (
  `event_id` int(11) NOT NULL,
  `dt_start` datetime NOT NULL,
  `dt_end` datetime NOT NULL,
  PRIMARY KEY (`event_id`,`dt_start`,`dt_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblEventImages`
--

CREATE TABLE IF NOT EXISTS `tblEventImages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file_img` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tblEventImages_1_idx` (`event_id`),
  KEY `fk_tblEventImages_2_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblEventInfo_us`
--

CREATE TABLE IF NOT EXISTS `tblEventInfo_us` (
  `event_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `dates` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblEventVendor`
--

CREATE TABLE IF NOT EXISTS `tblEventVendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `ordinal` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vendor_id`),
  KEY `fk_tblEventVendor_1_idx` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblEventVendorValues`
--

CREATE TABLE IF NOT EXISTS `tblEventVendorValues` (
  `vendor_id` int(11) NOT NULL,
  `key` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `keyindex` tinyint(3) unsigned NOT NULL,
  `value` char(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`vendor_id`,`key`,`keyindex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenu`
--

CREATE TABLE IF NOT EXISTS `tblMenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mod_ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mode_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_tblMenu_1` (`mode_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuComments`
--

CREATE TABLE IF NOT EXISTS `tblMenuComments` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `img_id` int(11) NOT NULL DEFAULT '0',
  `reply_id` bigint(20) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `edit_ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment` varchar(3000) NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `idx_tblMenuComments_1` (`menu_id`,`user_id`,`img_id`,`reply_id`),
  FULLTEXT KEY `ft_tblMenuComments_1` (`comment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuForkit`
--

CREATE TABLE IF NOT EXISTS `tblMenuForkit` (
  `menu_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `metadata_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`menu_id`,`section_id`,`metadata_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuImages`
--

CREATE TABLE IF NOT EXISTS `tblMenuImages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file_img` varchar(45) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tblMenuImages_1` (`menu_id`),
  KEY `fk_tblMenuImages_2` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuInfo_us`
--

CREATE TABLE IF NOT EXISTS `tblMenuInfo_us` (
  `menu_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `numbers` varchar(255) NOT NULL,
  `hours` varchar(255) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuLinks`
--

CREATE TABLE IF NOT EXISTS `tblMenuLinks` (
  `menu_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `keep` bit(1) NOT NULL,
  UNIQUE KEY `idx_tblMenuLinks_unique_1` (`menu_id`,`url`),
  KEY `fk_tblMenuLinks_1` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuMetadata`
--

CREATE TABLE IF NOT EXISTS `tblMenuMetadata` (
  `metadata_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `ordinal` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`metadata_id`),
  KEY `idx_tblMenuMetadata_1` (`menu_id`,`section_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuMetadataValues`
--

CREATE TABLE IF NOT EXISTS `tblMenuMetadataValues` (
  `metadata_id` int(11) NOT NULL,
  `key` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `keyindex` tinyint(3) unsigned NOT NULL,
  `value` char(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`metadata_id`,`key`,`keyindex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuSearch`
--

CREATE TABLE IF NOT EXISTS `tblMenuSearch` (
  `menu_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `metadata_id` bigint(20) NOT NULL,
  `search_text` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`menu_id`,`section_id`,`metadata_id`),
  FULLTEXT KEY `ft_tblMenuSearch_1` (`search_text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblMenuSection`
--

CREATE TABLE IF NOT EXISTS `tblMenuSection` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `ordinal` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` varchar(511) NOT NULL,
  PRIMARY KEY (`section_id`),
  KEY `idx_tblMenuSection_1` (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblPendingMenu`
--

CREATE TABLE IF NOT EXISTS `tblPendingMenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `site_addy1` varchar(511) NOT NULL,
  `site_addy2` varchar(511) NOT NULL,
  `site_addy3` varchar(511) NOT NULL,
  `site_addy4` varchar(511) NOT NULL,
  `site_addy5` varchar(511) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblPendingMenuImages`
--

CREATE TABLE IF NOT EXISTS `tblPendingMenuImages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pendingmenu_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `file_img` varchar(45) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tblPendingMenuImages_1` (`pendingmenu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblResetPassword`
--

CREATE TABLE IF NOT EXISTS `tblResetPassword` (
  `user_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reset_code` char(20) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `user_id_UNIQUE` (`user_id`),
  KEY `fk_tblResetPassword_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblTaggitsComment`
--

CREATE TABLE IF NOT EXISTS `tblTaggitsComment` (
  `menu_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `metadata_id` bigint(20) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`menu_id`,`section_id`,`metadata_id`,`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblTaggitsImage`
--

CREATE TABLE IF NOT EXISTS `tblTaggitsImage` (
  `menu_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `metadata_id` bigint(20) NOT NULL,
  `img_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`menu_id`,`section_id`,`metadata_id`,`img_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblUserPasswords`
--

CREATE TABLE IF NOT EXISTS `tblUserPasswords` (
  `user_id` int(11) NOT NULL,
  `password` char(40) NOT NULL,
  UNIQUE KEY `user_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblUserPermissions`
--

CREATE TABLE IF NOT EXISTS `tblUserPermissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  KEY `fk_tblUserPermissions_1` (`user_id`),
  KEY `fk_tblUserPermissions_2` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblUsers`
--

CREATE TABLE IF NOT EXISTS `tblUsers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `username` varbinary(255) NOT NULL,
  `email` varbinary(255) NOT NULL,
  `firstname` varbinary(100) NOT NULL,
  `lastname` varbinary(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `fk_tblUsers_1` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblUserValidation`
--

CREATE TABLE IF NOT EXISTS `tblUserValidation` (
  `user_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `validation_code` char(20) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `user_id_UNIQUE` (`user_id`),
  KEY `fk_tblUserValidation_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblEmailQueue`
--
ALTER TABLE `tblEmailQueue`
  ADD CONSTRAINT `fk_tblEmailQueue_1` FOREIGN KEY (`status_id`) REFERENCES `tblEnums` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblEvent`
--
ALTER TABLE `tblEvent`
  ADD CONSTRAINT `fk_tblEvent_1` FOREIGN KEY (`mode_id`) REFERENCES `tblEnums` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblEvent_2` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblEventImages`
--
ALTER TABLE `tblEventImages`
  ADD CONSTRAINT `fk_tblEventImages_1` FOREIGN KEY (`event_id`) REFERENCES `tblEvent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblEventImages_2` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblEventVendor`
--
ALTER TABLE `tblEventVendor`
  ADD CONSTRAINT `fk_tblEventVendor_1` FOREIGN KEY (`event_id`) REFERENCES `tblEvent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblMenu`
--
ALTER TABLE `tblMenu`
  ADD CONSTRAINT `fk_tblMenu_1` FOREIGN KEY (`mode_id`) REFERENCES `tblEnums` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblMenuImages`
--
ALTER TABLE `tblMenuImages`
  ADD CONSTRAINT `fk_tblMenuImages_1` FOREIGN KEY (`menu_id`) REFERENCES `tblMenu` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `tblMenuImages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tblMenuLinks`
--
ALTER TABLE `tblMenuLinks`
  ADD CONSTRAINT `fk_tblMenuLinks_1` FOREIGN KEY (`menu_id`) REFERENCES `tblMenu` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tblPendingMenuImages`
--
ALTER TABLE `tblPendingMenuImages`
  ADD CONSTRAINT `fk_tblPendingMenuImages_1` FOREIGN KEY (`pendingmenu_id`) REFERENCES `tblPendingMenu` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tblResetPassword`
--
ALTER TABLE `tblResetPassword`
  ADD CONSTRAINT `fk_tblResetPassword_1` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tblUserPasswords`
--
ALTER TABLE `tblUserPasswords`
  ADD CONSTRAINT `fk_tblUserPasswords_1` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tblUserPermissions`
--
ALTER TABLE `tblUserPermissions`
  ADD CONSTRAINT `fk_tblUserPermissions_1` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblUserPermissions_2` FOREIGN KEY (`permission_id`) REFERENCES `tblEnums` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblUsers`
--
ALTER TABLE `tblUsers`
  ADD CONSTRAINT `fk_tblUsers_1` FOREIGN KEY (`status`) REFERENCES `tblEnums` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblUserValidation`
--
ALTER TABLE `tblUserValidation`
  ADD CONSTRAINT `fk_tblUserValidation_1` FOREIGN KEY (`user_id`) REFERENCES `tblUsers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
